/**
 *  @author Richard Klem, xklemr00@fit.vutbr.cz
 *  @date 28.4.2019
 *  @license  Some principes are inspired by Little book of Semaphores
 *            Barrierr and shm code is inspired from Ing. Radek Koci, Ph.D.
 */

/**
 *  #######################---Programme information---########################
 *  @brief Programme is solving river crossing problem with boat come back
 *		and with some other differencies
 *  @problems Captain could by mistake free another captain from queues.
 *          This causes some problems and programme will not end successfully.
 *          Also the programme does not run correctly with higher mole(wharf)
 *          capacity and with higher number of processes/people.
 *          Sometimes some unexpected situation occured when another group is
 *          ready but previous group hasn't came back yet.
 *
 *          Also I was working on better version with own captains queues
 *          and with other features which handle variety of problems but
 *          unfortunetly I wasn't able to finish that version before deadline.
 *          That improved version dosn't worked at all, so I was forced
 *          to submit this much older version. Bad luck for me...
 *  #########################################################################
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <semaphore.h>
#include "proj2.h"

#define SHM_NAME "/xklemr00-ios-proj2-shm"
#define NH_NAME "/xklemr00-ios-proj2-nh"
#define NS_NAME "/xklemr00-ios-proj2-ns"
#define ACTION_COUNTER_NAME "/xklemr00-ios-proj2-action_counter"
#define BBB_SHM_NAME "/xklemr00-ios-proj2-bbb_shm"
#define ARB_SHM_NAME "/xklemr00-ios-proj2-arb_shm"
#define CLLB_SHM_NAME "/xklemr00-ios-proj2-cllb_shm"

#define SEM_NAME_GM "/xklemr00-ios-proj2-generalMutex"
#define SEM_NAME_WM "/xklemr00-ios-proj2-wharfMutex"
#define SEM_NAME_BS "/xklemr00-ios-proj2-boatSemaphore"
#define SEM_NAME_BM "/xklemr00-ios-proj2-boatMutex"
#define SEM_NAME_HQ "/xklemr00-ios-proj2-hackersQueue"
#define SEM_NAME_SQ "/xklemr00-ios-proj2-serfsQueue"
#define SEM_NAME_BBB "/xklemr00-ios-proj2-bbb_sem"
#define SEM_NAME_ARB "/xklemr00-ios-proj2-arb_sem"
#define SEM_NAME_CLLB "/xklemr00-ios-proj2-cllb_sem"

#define ARGC_ERROR "Arguments count error"
#define ARGV_ERROR "Argument value or format error"
#define FOPEN_ERROR "File opening error"
#define FCLOSE_ERROR "File closing error"
#define SEM_ERROR "Semaphore action (creating or etc.) failed"


int peopleCount = 2;
int hackGenTime = 0;
int serfGenTime = 0;
int rowTime = 0;
int wharfWait = 20;
int wharfCap = 5;

int *shm = NULL;
int *nh = NULL;//hackers at wharf
int *ns = NULL; //serfs at wharf
int *action_counter = NULL; //number of action

sem_t *generalMutex; //mutex for general actions
sem_t *boatSem; //semaphore for undistrubed cruise
sem_t *boatMutex; //mutex to provide unchanged ns & nh number while exiting boat
sem_t *wharfMutex; //mutex for undistrubed come to wharf
sem_t *hackersQueue; //semaphore for hackers in their queue at wharf
sem_t *serfsQueue; //semaphore for serfs in their queue at wharf

barrier_t before_board_barrier;
barrier_t after_row_barrier;
barrier_t captain_leaves_last_barrier;

FILE *proj2_output = NULL;

void barrier_join(barrier_t *barrier)
{
    barrier->shm[0]++;
    if (*barrier->shm == barrier->size) {
        for (int i = 0; i < barrier->size-1; i++) {
            sem_post(barrier->sem);
        }
        barrier->shm[0] = 0;
    } else {
        sem_wait(barrier->sem);
    }
}

void b_close()
{
    sem_close(generalMutex);
    sem_close(hackersQueue);
    sem_close(serfsQueue);
    sem_close(boatSem);
    sem_close(boatMutex);
    sem_close(before_board_barrier.sem);
    sem_close(after_row_barrier.sem);
    sem_close(captain_leaves_last_barrier.sem);

    munmap(shm, sizeof(int));
    munmap(nh, sizeof(int));
    munmap(ns, sizeof(int));
    munmap(action_counter, sizeof(int));
    munmap(before_board_barrier.shm, sizeof(int));
    munmap(after_row_barrier.shm, sizeof(int));
    munmap(captain_leaves_last_barrier.shm, sizeof(int));
}

void b_init()
{
    int shmID;
    int nhID;
    int nsID;
    int action_counterID;
    int bbb_shmID;
    int arb_shmID;
    int cllb_shmID;

    shmID = shm_open(SHM_NAME, O_CREAT | O_EXCL | O_RDWR, S_IRUSR | S_IWUSR);
    ftruncate(shmID, sizeof(int));
    shm = (int*)mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, shmID, 0);
    close(shmID);

    nhID = shm_open(NH_NAME, O_CREAT | O_EXCL | O_RDWR, S_IRUSR | S_IWUSR);
    ftruncate(nhID, sizeof(int));
    nh = (int*)mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, nhID, 0);
    close(nhID);

    nsID = shm_open(NS_NAME, O_CREAT | O_EXCL | O_RDWR, S_IRUSR | S_IWUSR);
    ftruncate(nsID, sizeof(int));
    ns = (int*)mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, nsID, 0);
    close(nsID);

    action_counterID = shm_open(ACTION_COUNTER_NAME, O_CREAT | O_EXCL | O_RDWR, S_IRUSR | S_IWUSR);
    ftruncate(action_counterID, sizeof(int));
    action_counter = (int*)mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, action_counterID, 0);
    close(action_counterID);

    bbb_shmID = shm_open(BBB_SHM_NAME, O_CREAT | O_EXCL | O_RDWR, S_IRUSR | S_IWUSR);
    ftruncate(bbb_shmID, sizeof(int));
    before_board_barrier.shm = (int*)mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, bbb_shmID, 0);
    close(bbb_shmID);

    arb_shmID = shm_open(ARB_SHM_NAME, O_CREAT | O_EXCL | O_RDWR, S_IRUSR | S_IWUSR);
    ftruncate(arb_shmID, sizeof(int));
    after_row_barrier.shm = (int*)mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, arb_shmID, 0);
    close(arb_shmID);

    cllb_shmID = shm_open(ARB_SHM_NAME, O_CREAT | O_EXCL | O_RDWR, S_IRUSR | S_IWUSR);
    ftruncate(cllb_shmID, sizeof(int));
    captain_leaves_last_barrier.shm = (int*)mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED, cllb_shmID, 0);
    close(cllb_shmID);



    generalMutex = sem_open(SEM_NAME_GM, O_CREAT, 0666, 1); //create mutex
    wharfMutex = sem_open(SEM_NAME_WM, O_CREAT, 0666, 1);
    boatSem = sem_open(SEM_NAME_BS, O_CREAT, 0666, 4);
    boatMutex = sem_open(SEM_NAME_BM, O_CREAT, 0666, 1);
    hackersQueue = sem_open(SEM_NAME_HQ, O_CREAT, 0666, 0);
    serfsQueue = sem_open(SEM_NAME_SQ, O_CREAT, 0666, 0);
    before_board_barrier.sem = sem_open(SEM_NAME_BBB, O_CREAT, 0666, 0);
    after_row_barrier.sem = sem_open(SEM_NAME_ARB, O_CREAT, 0666, 0);
    captain_leaves_last_barrier.sem = sem_open(SEM_NAME_CLLB, O_CREAT, 0666, 0);

    after_row_barrier.size = 4;
    before_board_barrier.size = 4;
    captain_leaves_last_barrier.size = 4;
}

void b_unlink()
{
    shm_unlink(SHM_NAME);
    shm_unlink(NH_NAME);
    shm_unlink(NS_NAME);
    shm_unlink(ACTION_COUNTER_NAME);
    shm_unlink(BBB_SHM_NAME);
    shm_unlink(ARB_SHM_NAME);
    shm_unlink(CLLB_SHM_NAME);

    sem_unlink(SEM_NAME_GM);
    sem_unlink(SEM_NAME_HQ);
    sem_unlink(SEM_NAME_SQ);
    sem_unlink(SEM_NAME_WM);
    sem_unlink(SEM_NAME_BS);
    sem_unlink(SEM_NAME_BM);
    sem_unlink(SEM_NAME_BBB);
    sem_unlink(SEM_NAME_ARB);
    sem_unlink(SEM_NAME_CLLB);
}

void safe_error_exit()
{
  b_unlink();
  exit(1);
}

int args_check_n_set(int argc, char const *argv[])
{
  //-------Convert chars to integers-------
  int args[6]; //array for converted arguments
  for (int i = 0; i < argc - 1; i++)
  {
    args[i] = atoi(argv[i + 1]);
  }

  if (argc != 7) {
    fprintf(stderr, "%s\n", ARGC_ERROR);
    safe_error_exit();
  }
  //-------Number of people to generate-------
  if (args[0] >= 2 && (args[0] % 2) == 0)
  {
    peopleCount = args[0];
  }
  else
  {
    fprintf(stderr, "%s\n", ARGV_ERROR);
    safe_error_exit();
  }
  //-------Hackers generation time-------
  if (args[1] >= 0 && args[1] <= 2000)
  {
    hackGenTime = args[1];
  }
  else
  {
    fprintf(stderr, "%s\n", ARGV_ERROR);
    safe_error_exit();
  }
  //-------Serfs generation time-------
  if (args[2] >= 0 && args[2] <= 2000)
  {
    serfGenTime = args[2];
  }
  else
  {
    fprintf(stderr, "%s\n", ARGV_ERROR);
    safe_error_exit();
  }
  //-------Row time-------
  if (args[3] >= 0 && args[3] <= 2000)
  {
    rowTime = args[3];
  }
  else
  {
    fprintf(stderr, "%s\n", ARGV_ERROR);
    safe_error_exit();
  }
  //-------Wharf waiting time-------
  if (args[4] >= 20 && args[4] <= 2000)
  {
    wharfWait = args[4];
  }
  else
  {
    fprintf(stderr, "%s\n", ARGV_ERROR);
    safe_error_exit();
  }
  //-------Wharf capacity-------
  if (args[5] >= 5)
  {
    wharfCap = args[5];
  }
  else
  {
    fprintf(stderr, "%s\n", ARGV_ERROR);
    safe_error_exit();
  }
  return 0;
}

int wharfAction(char *squad, int pid)
{
    int isCaptain = 0; //local variable for every process
    //process is reading from shm, needs private acces

    sem_wait(generalMutex);
    while (((*nh) + (*ns)) == wharfCap)
    {
        fprintf(proj2_output,  "%d    : %s %d    : leaves queue    : %d    : %d\n", ++action_counter[0], squad, pid, *nh, *ns);
        fflush(proj2_output);
        sem_post(generalMutex); //leave mutex after write so others can do so

        if (wharfWait > 20)
        {
            usleep((rand() %(wharfWait-20) + 20)*1000); //sleep before next round
        }

        sem_wait(generalMutex); //process will write shm variables
        fprintf(proj2_output,  "%d    : %s %d    : is back\n", ++action_counter[0], squad, pid);
        fflush(proj2_output);
        sem_post(generalMutex); //leave mutex after write so others can do so

        //process keeps mutex because next while ask process could want
        //  go to the queue at the wharf if the wharf will be still full
        //  process gives up mutex immediatly after while cycle ask
        sem_wait(generalMutex); //same as before while cycle
    }

    sem_post(generalMutex);

    sem_wait(wharfMutex); //undistrubed come and actions at the wharf
    sem_wait(generalMutex);


//-----------------------_HACKERS_WHARF_PART_----------------------------
    if(strcmp(squad, "HACK") == 0)
    {
        nh[0]++; //process write itself to hackers

        fprintf(proj2_output, "%d    : %s %d    : waits    : %d    : %d\n", ++action_counter[0], squad, pid, *nh, *ns);
        fflush(proj2_output);

        if (*nh == 4)
        {
            sem_post(generalMutex);
            //sem_post(wharfMutex);
            sem_wait(boatMutex);
            //sem_wait(wharfMutex);
            sem_wait(generalMutex);
            //free 4 hackers
            for (int i = 0; i < 4; ++i)
            {
                sem_post(hackersQueue);
            }
            *nh = 0;
            isCaptain = 1; //process set itself captain

        }
        else if ((*nh == 2) && (*ns >= 2))
        {
            sem_post(generalMutex);
            //sem_post(wharfMutex);
            sem_wait(boatMutex);
            //sem_wait(wharfMutex);
            sem_wait(generalMutex);
            //free 2 hackers and 2 serfs
            for (int i = 0; i < 2; ++i)
            {
                sem_post(hackersQueue);
                sem_post(serfsQueue);
            }
            *ns -= 2;
            *nh = 0;
            isCaptain = 1; //process set itself captain
        }

        if (isCaptain == 0)
        {
            sem_post(wharfMutex); //post wharfMutex because won't lead a row
            sem_post(generalMutex);
        }
        else if(isCaptain == 1)
        {
            sem_post(generalMutex); //I want to captain keeps mutex
            //sem_wait(generalMutex); //but also others can do some action
        }
        sem_wait(hackersQueue); // =count of hackers increments
    }

//-----------------------_SERFS_WHARF_PART_----------------------------
    else if(strcmp(squad, "SERF") == 0)
    {
        ns[0]++; //process write itself to serfs queue

        fprintf(proj2_output, "%d    : %s %d    : waits    : %d    : %d\n", ++action_counter[0], squad, pid, *nh, *ns);
        fflush(proj2_output);

        if (*ns == 4)
        {
            sem_post(generalMutex);
            //sem_post(wharfMutex);
            sem_wait(boatMutex);
            //sem_wait(wharfMutex);
            sem_wait(generalMutex);
            //free 4 serfs
            for (int i = 0; i < 4; ++i)
            {
                sem_post(serfsQueue);
            }
            *ns = 0;
            isCaptain = 1; //process set itself captain
        }
        else if ((*ns == 2) && (*nh >= 2))
        {
            sem_post(generalMutex);
            //sem_post(wharfMutex);
            sem_wait(boatMutex);
            //sem_wait(wharfMutex);
            sem_wait(generalMutex);
            //free 2 hackers and 2 serfs
            for (int i = 0; i < 2; ++i)
            {
                sem_post(hackersQueue);
                sem_post(serfsQueue);
            }
            *nh -= 2;
            *ns = 0;
            isCaptain = 1; //process set itself captain
        }

        if (isCaptain == 0)
        {
            sem_post(wharfMutex); //post wharfMutex because won't lead a row
            sem_post(generalMutex);
        }
        else if(isCaptain == 1)
        {
            sem_post(generalMutex); //I want to captain keeps mutex
            //sem_post(wharfMutex);
        }
        sem_wait(serfsQueue); // =count of serfs increments
    }
//----------------------_BOAT_BOARDING_---------------------------
    if (isCaptain == 1)
    {
        sem_wait(generalMutex);
    }

    barrier_join(&before_board_barrier);

    if (isCaptain == 1)
    {
        //sem_wait(wharfMutex);
        fprintf(proj2_output, "%d    : %s %d    : boards    : %d    : %d\n", ++action_counter[0], squad, pid, *nh, *ns);
        fflush(proj2_output);

        sem_post(generalMutex);

        sem_post(wharfMutex);
        if (rowTime > 0)
        {
            usleep((rand() % rowTime)*1000);
        }
    }

    barrier_join(&after_row_barrier);

//------------------------_BOAT_EXITING_--------------------------
    char *type = "member";
    if (isCaptain == 1)
    {
        //change string for output
        type = "captain";
        //catain needs to wait untill all other process leaves the boat
        sem_wait(captain_leaves_last_barrier.sem);
    }

    sem_wait(generalMutex);

    fprintf(proj2_output, "%d    : %s %d    : %s exits    : %d    : %d\n", ++action_counter[0], squad, pid, type, *nh, *ns);
    fflush(proj2_output);

    if (isCaptain == 0)
    {

        ++shm[0];

        if(shm[0] == 3)
        {
            sem_post(captain_leaves_last_barrier.sem);
        }
    }
    else if(isCaptain == 1)
    {
        shm[0] = 0; //set counter for another boat
        sem_post(boatMutex);
    }

    sem_post(generalMutex);

    return 0;
}

//---------------------------__MAIN__-------------------------------
int main(int argc, char const *argv[])
{
    args_check_n_set(argc, argv);

    char *squad = "HACK";
    int pid; //internal id of child processes
    setbuf(stderr,NULL);
    if ((proj2_output = fopen("proj2.out", "w")) == NULL)
    {
        fprintf(stderr, "%s\n", FOPEN_ERROR);
        exit(2);
    }


    b_init();

    for (int i = 1; i <= 2; i++)
    {
        //-------GENERATORS_FORK--------
        sem_wait(generalMutex);
        if ((pid = fork()) < 0) {
            perror("fork");
            b_close();
            safe_error_exit();
        }
        if (pid == 0)
        {
            sem_post(generalMutex);
            for (int j = 1; j <= peopleCount; j++)
            {
                if (i == 2)
                {
                    squad = "SERF";
                }
                //-----PROCESSES_FORK-------
                sem_wait(generalMutex);
                if ((pid = fork()) < 0)
                {
                    perror("fork");
                    b_close();
                    safe_error_exit();
                }
                if (pid == 0)
                {
                    fprintf(proj2_output, "%d    : %s %d    : starts\n", ++action_counter[0], squad, j);
                    fflush(proj2_output);
                    sem_post(generalMutex);
                    wharfAction(squad, j);
                    exit(0);
                }
                if (i == 1 && (hackGenTime > 0))
                {
                    usleep((rand() %(hackGenTime))*1000);
                }
                else if (i == 2 && (serfGenTime > 0))
                {
                    usleep((rand() %(serfGenTime))*1000);
                }
            }
            for (int i = 0; i < (peopleCount); ++i) {
              wait(NULL);
            }
            exit(0);
        }
    }
    b_close();

    if ((fclose(proj2_output)) == EOF)
    {
        fprintf(stderr, "%s\n", FCLOSE_ERROR);
        safe_error_exit();
    }
  //waiting for ending all processes
  for (int i = 0; i < (2*(peopleCount + 1)); ++i) {
    wait(NULL);
  }

  // zrusime zdroje
  b_unlink();
  return 0;
}










//konec
