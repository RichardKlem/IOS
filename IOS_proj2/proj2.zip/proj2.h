/**
 *  @author: Richard Klem, xklemr00@fit.vutbr.cz
 *  @date: 28.4.2019
 */
 typedef struct {
     sem_t *sem;
     int *shm;
     int size;
 } barrier_t;

void safe_error_exit();

int args_check_n_set(int argc, char const *argv[]);

void barrier_join(barrier_t *barrier);

void b_close();

void b_init();

void b_unlink();

int wharfAction(char *squad, int pid);
